insert into pizza(id,name,veg,price,quantity,image) values(1, 'Margherita', 1,100,45, 'https://api.pizzahut.io/v1/content/en-in/in-1/images/pizza/margherita.90f9451fd66871fb6f9cf7d506053f18.1.jpg?width=550');
insert into pizza(id,name,veg,price,quantity,image) values(2, 'Tandoori Paneer', 1,105,45, 'https://api.pizzahut.io/v1/content/en-in/in-1/images/pizza/tandoori-paneer.4ef45717e972cf45b43c010e3cde5a22.1.jpg?width=550');

insert into pizza(id,name,veg,price,quantity,image) values(3, 'Veggie Supreme', 1,95,45, 'https://api.pizzahut.io/v1/content/en-in/in-1/images/pizza/veggie-supreme.bc8dd369182b636ff171077efa53c344.1.jpg?width=550');

insert into pizza(id,name,veg,price,quantity,image) values(4, 'Double Paneer ', 1,200,45, 'https://api.pizzahut.io/v1/content/en-in/in-1/images/pizza/veggie-supreme.bc8dd369182b636ff171077efa53c344.1.jpg?width=550');

insert into pizza(id,name,veg,price,quantity,image) values(5, 'Veggie Kebab ', 0,70,45, 'https://api.pizzahut.io/v1/content/en-in/in-1/images/pizza/veg-kebab-surprise.abab1dff179ab8cf95a59f30d6352297.1.jpg?width=550');

insert into admin(id,password) values('1123451','mantoshk1');