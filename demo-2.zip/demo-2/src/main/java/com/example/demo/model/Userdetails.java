package com.example.demo.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Userdetails {
	@Id
	private int id;
	private String name;
	private String address;
	private String city;
	private String state;
	private int pin;
	private String mobilenumber;
	private String landlinenumber;
	private String email;
	public Userdetails(int id, String name, String address, String city, String state, int pin, String mobilenumber,
			String landlinenumber, String email) {
		
		this.id = id;
		this.name = name;
		this.address = address;
		this.city = city;
		this.state = state;
		this.pin = pin;
		this.mobilenumber = mobilenumber;
		this.landlinenumber = landlinenumber;
		this.email = email;
	}
	
	public Userdetails() {
		super();
	}

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public int getPin() {
		return pin;
	}
	public void setPin(int pin) {
		this.pin = pin;
	}
	public String getMobilenumber() {
		return mobilenumber;
	}
	public void setMobilenumber(String mobilenumber) {
		this.mobilenumber = mobilenumber;
	}
	public String getLandlinenumber() {
		return landlinenumber;
	}
	public void setLandlinenumber(String landlinenumber) {
		this.landlinenumber = landlinenumber;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
}
