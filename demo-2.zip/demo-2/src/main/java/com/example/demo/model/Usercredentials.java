package com.example.demo.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Usercredentials {
	@Id
	private String userid;
	private String usertype;
	private String password;
	private String loginstatus;
	public Usercredentials(String userid, String usertype, String password, String loginstatus) {
		super();
		this.userid = userid;
		this.usertype = usertype;
		this.password = password;
		this.loginstatus = loginstatus;
	}
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getUsertype() {
		return usertype;
	}
	public void setUsertype(String usertype) {
		this.usertype = usertype;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getLoginstatus() {
		return loginstatus;
	}
	public void setLoginstatus(String loginstatus) {
		this.loginstatus = loginstatus;
	}
	
	
}
