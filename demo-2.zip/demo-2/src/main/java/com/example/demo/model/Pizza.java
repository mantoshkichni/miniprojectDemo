package com.example.demo.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Pizza {
	@Id
	private int id;
	private String name;
	private int veg;
	private int price;
	private int quantity;
	private String image;
	
	public Pizza(int id, String name, int veg, int price, int quantity, String image) {
		super();
		this.id = id;
		this.name = name;
		this.veg = veg;
		this.price = price;
		this.quantity = quantity;
		this.image = image;
	}
	
	public Pizza() {
		super();
	}

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public int getVeg() {
		return veg;
	}
	public void setVeg(int veg) {
		this.veg = veg;
	}
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	
	
}
