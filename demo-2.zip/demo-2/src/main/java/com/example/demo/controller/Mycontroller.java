package com.example.demo.controller;

import java.util.ArrayList;

import org.hibernate.mapping.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.example.demo.model.Pizza;
import com.example.demo.model.Usercredentials;
import com.example.demo.model.Userdetails;
import com.example.demo.repository.Pizzarepository;
import com.example.demo.repository.UsercredentialsRepo;
import com.example.demo.repository.UserdetailsRepo;

import jakarta.servlet.http.HttpServletRequest;



@Controller
public class Mycontroller {
	@Autowired
	Pizzarepository pizzarepo;
	@Autowired
	UsercredentialsRepo usercredentialsrepo;
	@Autowired
	UserdetailsRepo userdetailsrepo;
	
	

	@RequestMapping("/")
	public String homepage()
	{
		return "index";
	}
	@RequestMapping("/pizza")
	public ModelAndView getPizza()
	{
		ModelAndView mv=new ModelAndView();
		try {
		
			ArrayList<Pizza> listpizza=new ArrayList<>();
			listpizza=(ArrayList<Pizza>) pizzarepo.findAll();
			mv.addObject("listpizza",listpizza);
			mv.setViewName("pizza");
			return mv;
		} catch (Exception e) {
			System.out.println(e);
		}
		mv.setViewName("error");
		return mv;
	}
	@RequestMapping( value="/user",method = RequestMethod.GET)
	public String getUser()
	{
		return "signupForm";
	}
	@RequestMapping( value="/user",method = RequestMethod.POST)
	public String saveUser(HttpServletRequest req)
	{
		int id=Integer.parseInt(req.getParameter("id"));
		int pin=Integer.parseInt(req.getParameter("pin"));
		String name=req.getParameter("name");
		String address=req.getParameter("address");
		String city=req.getParameter("city");
		String state=req.getParameter("state");
		String email=req.getParameter("email");
		String mobile=req.getParameter("mobile");
		String landlind=req.getParameter("landline");
		Userdetails user=new Userdetails(id, name, address, city, state, pin, mobile, landlind, email);
		userdetailsrepo.save(user);
		
		System.out.println(id);
		return "redirect:user";
	}
	
}
