package com.example.demo.model;

import java.math.BigInteger;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class UserDetails {
	@Id
	private long userId;
	private String name;
	private String address;
	private String city;
	private String state;
	private int pin;
	private long mobileNo;
	private long landline;
	private String Emailid;
	
}
