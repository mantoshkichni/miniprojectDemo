package com.example.demo.model;

import java.math.BigInteger;
import java.time.LocalDate;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;

@Entity
public class CreditcardDetails {
		@Id
	    private long userId;
	 	private String creditCardNumber;
	 	private LocalDate validFrom;
	 	private LocalDate validUpto;
		public long getUserId() {
			return userId;
		}
		public void setUserId(long userId) {
			this.userId = userId;
		}
		public String getCreditCardNumber() {
			return creditCardNumber;
		}
		public void setCreditCardNumber(String creditCardNumber) {
			this.creditCardNumber = creditCardNumber;
		}
		public LocalDate getValidFrom() {
			return validFrom;
		}
		public void setValidFrom(LocalDate validFrom) {
			this.validFrom = validFrom;
		}
		public LocalDate getValidUpto() {
			return validUpto;
		}
		public void setValidUpto(LocalDate validUpto) {
			this.validUpto = validUpto;
		}
		@Override
		public String toString() {
			return "CreditcardDetails [userId=" + userId + ", creditCardNumber=" + creditCardNumber + ", validFrom="
					+ validFrom + ", validUpto=" + validUpto + "]";
		}
	 	
	 	
}
