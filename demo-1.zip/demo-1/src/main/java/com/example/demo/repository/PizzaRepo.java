package com.example.demo.repository;

import org.springframework.data.repository.CrudRepository;

import com.example.demo.model.Pizza;

//public interface PizzaRepo extends CrudRepository<Pizza, Integer> {
//
//}
