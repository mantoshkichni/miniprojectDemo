package com.example.demo.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Pizza {
	@Id
	private int id;
	private String name;
	private boolean veg;
	private int price;
	private int quantity;
	private String image;
	private String description;

	public Pizza() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Pizza(int id, String name, boolean veg, int price, int quantity, String image, String description) {
		super();
		this.id = id;
		this.name = name;
		this.veg = veg;
		this.price = price;
		this.quantity = quantity;
		this.image = image;
		this.description = description;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public boolean isVeg() {
		return veg;
	}

	public void setVeg(boolean veg) {
		this.veg = veg;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	@Override
	public String toString() {
		return "Pizza [id=" + id + ", name=" + name + ", veg=" + veg + ", price=" + price + ", quantity=" + quantity
				+ ", image=" + image + ", description=" + description + "]";
	}

}
