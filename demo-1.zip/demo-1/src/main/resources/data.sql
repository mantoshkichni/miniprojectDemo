
Insert into PIZZA(id,name,veg,price,quantity,image,description) values(2,'Margherita',true,3,1,'https://api.pizzahut.io/v1/content/en-in/in-1/images/pizza/margherita.90f9451fd66871fb6f9cf7d506053f18.1.jpg?width=550','qwertyui');
